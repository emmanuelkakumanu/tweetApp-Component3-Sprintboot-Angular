export class Like{
    tweetId : number;
    username  :  string;
}