export class Reply{
    comment : string;
    constructor(comment){
        this.comment = comment;
    }
}